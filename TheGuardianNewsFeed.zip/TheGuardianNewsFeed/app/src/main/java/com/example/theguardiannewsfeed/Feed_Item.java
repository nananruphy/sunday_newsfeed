package com.example.theguardiannewsfeed;

public class Feed_Item {
    private static final String NO_THUMBNAIL = "No String Found";

    private String webTitle;
    private String webUrl;
    private String thumbnailLink = NO_THUMBNAIL;

    public Feed_Item(String webTitle, String webUrl, String thumbnailLink) {
        this.webTitle = webTitle;
        this.webUrl = webUrl;
        this.thumbnailLink = thumbnailLink;
    }

    public Feed_Item(String webTitle, String webUrl) {
        this.webTitle = webTitle;
        this.webUrl = webUrl;
    }

    public String getWebTitle() {
        return webTitle;
    }

    public String getWebUrl() {
        return webUrl;
    }

    public String getThumbnailLink() {
        return thumbnailLink;
    }

    public boolean hasThumbnail() {
        return !this.thumbnailLink.equals(NO_THUMBNAIL);
    }
}


